package org.packt.springboot22.vid02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
