package org.packt.springboot22.vid02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section12Application {

	public static void main(String[] args) {
		SpringApplication.run(Section12Application.class, args);
	}

}
